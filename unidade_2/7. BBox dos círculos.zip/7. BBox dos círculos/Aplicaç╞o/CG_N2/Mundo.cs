﻿/**
  Autor: Dalton Solano dos Reis
**/

#define CG_Gizmo
// #define CG_Privado

using System;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using System.Collections.Generic;
using OpenTK.Input;
using CG_Biblioteca;

namespace gcgcg
{
    class Mundo : GameWindow
    {
        private static Mundo instanciaMundo = null;

        private Mundo(int width, int height) : base(width, height) { }

        public static Mundo GetInstance(int width, int height)
        {
            if (instanciaMundo == null)
                instanciaMundo = new Mundo(width, height);
            return instanciaMundo;
        }

        private CameraOrtho camera = new CameraOrtho();
        protected List<Objeto> objetosLista = new List<Objeto>();
        private Circulo objetoSelecionado = null;        
        private bool bBoxDesenhar = false;
        int mouseX, mouseY;  
        private bool mouseMoverPto = false;
        private Circulo obj_circulo_menor;
        private Circulo obj_circulo_maior;
        private double raio;
#if CG_Privado
        private Privado_SegReta obj_SegReta;
        private Privado_Circulo obj_Circulo;
#endif
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            camera.xmin = -10;
            camera.xmax = 590;
            camera.ymin = -10;
            camera.ymax = 590;

            Console.WriteLine(" --- Ajuda / Teclas: ");
            Console.WriteLine(" [  H     ] mostra teclas usadas. ");

            raio = 200;
            obj_circulo_maior = new Circulo("C1", null, 5, raio, false, new Ponto4D(300, 300));
            obj_circulo_maior.ObjetoCor.CorR = 0;
            obj_circulo_maior.ObjetoCor.CorG = 0;
            obj_circulo_maior.ObjetoCor.CorB = 0;
            objetosLista.Add(obj_circulo_maior);            
            raio = Math.Pow(raio, 2);

            obj_circulo_menor = new Circulo("C2", null, 10, 50, true, new Ponto4D(300, 300));
            obj_circulo_menor.ObjetoCor.CorR = 0;
            obj_circulo_menor.ObjetoCor.CorG = 0;
            obj_circulo_menor.ObjetoCor.CorB = 0;
            objetosLista.Add(obj_circulo_menor);
            objetoSelecionado = obj_circulo_menor;

#if CG_Privado
            obj_SegReta = new Privado_SegReta("B", null, new Ponto4D(50, 150), new Ponto4D(150, 250));
            obj_SegReta.ObjetoCor.CorR = 255; obj_SegReta.ObjetoCor.CorG = 255; obj_SegReta.ObjetoCor.CorB = 0;
            objetosLista.Add(obj_SegReta);
            objetoSelecionado = obj_SegReta;

            obj_Circulo = new Privado_Circulo("C", null, new Ponto4D(100, 300), 50);
            obj_Circulo.ObjetoCor.CorR = 0; obj_Circulo.ObjetoCor.CorG = 255; obj_Circulo.ObjetoCor.CorB = 255;
            objetosLista.Add(obj_Circulo);
            objetoSelecionado = obj_Circulo;
#endif
            GL.ClearColor(0.5f,0.5f,0.5f,1.0f);
        }
        
        protected override void OnUpdateFrame(FrameEventArgs e)
        {
            base.OnUpdateFrame(e);
            GL.MatrixMode(MatrixMode.Projection);
            GL.LoadIdentity();
            GL.Ortho(camera.xmin, camera.xmax, camera.ymin, camera.ymax, camera.zmin, camera.zmax);
        }
        protected override void OnRenderFrame(FrameEventArgs e)
        {
            base.OnRenderFrame(e);
            GL.Clear(ClearBufferMask.ColorBufferBit);
            GL.MatrixMode(MatrixMode.Modelview);
            GL.LoadIdentity();
    #if CG_Gizmo      
            Sru3D();
    #endif
            for (var i = 0; i < objetosLista.Count; i++)
                objetosLista[i].Desenhar();
            if (bBoxDesenhar && (obj_circulo_maior != null)){
                obj_circulo_maior.BBox.Desenhar();                
            }
            this.SwapBuffers();
        }

        protected override void OnKeyDown(OpenTK.Input.KeyboardKeyEventArgs e)
        {
            if (e.Key == Key.H)
                Utilitario.AjudaTeclado();
            else if (e.Key == Key.Escape)
                Exit();
            else if (e.Key == Key.O)
                bBoxDesenhar = !bBoxDesenhar;
            else if (e.Key == Key.V)
                mouseMoverPto = !mouseMoverPto; 
            else
                Console.WriteLine(" __ Tecla não implementada.");
        }

        public double DistanciaEuclidiana(Ponto4D pontoOrigemMenor, Ponto4D pontoOrigemMaior)
        {
            //Versão 1
            //return Math.Sqrt(Math.Pow(pontoOrigemMenor.X - pontoOrigemMaior.X, 2) + Math.Pow(pontoOrigemMenor.Y - pontoOrigemMaior.Y, 2));
            //Versão 2
            return Math.Pow(pontoOrigemMenor.X - pontoOrigemMaior.X, 2) + Math.Pow(pontoOrigemMenor.Y - pontoOrigemMaior.Y, 2);
        }

        protected override void OnMouseMove(MouseMoveEventArgs e)
        {
            mouseX = e.Position.X -10; 
            mouseY = 600 - e.Position.Y; // Inverti eixo Y
            if (mouseMoverPto){
                if((mouseX > obj_circulo_maior.BBoxInternaCirculo.obterMenorX)
                && (mouseX < obj_circulo_maior.BBoxInternaCirculo.obterMaiorX)
                && (mouseY > obj_circulo_maior.BBoxInternaCirculo.obterMenorY)
                && (mouseY < obj_circulo_maior.BBoxInternaCirculo.obterMaiorY)){
                    //Muda de cor, pois está dentro da BBox Interna
                    objetoSelecionado.PontoOrigem().X = mouseX;
                    objetoSelecionado.PontoOrigem().Y = mouseY;
                    obj_circulo_maior.BBoxInternaCirculo.ObjetoCor.CorR = 169;
                    obj_circulo_maior.BBoxInternaCirculo.ObjetoCor.CorG = 122;
                    obj_circulo_maior.BBoxInternaCirculo.ObjetoCor.CorB = 171;
                }
                else{                    
                    if (DistanciaEuclidiana(obj_circulo_menor.PontoOrigem(), obj_circulo_maior.PontoOrigem()) < raio)
                    {//Saiu da BBox Interna, então calcula a distância euclidiana
                        objetoSelecionado.PontoOrigem().X = mouseX;
                        objetoSelecionado.PontoOrigem().Y = mouseY;
                        obj_circulo_maior.BBoxInternaCirculo.ObjetoCor.CorR = 255;
                        obj_circulo_maior.BBoxInternaCirculo.ObjetoCor.CorG = 255;
                        obj_circulo_maior.BBoxInternaCirculo.ObjetoCor.CorB = 0;
                    }
                    else
                    {//Bateu nas bordas do círculo maior
                        obj_circulo_maior.BBoxInternaCirculo.ObjetoCor.CorR = 180;
                        obj_circulo_maior.BBoxInternaCirculo.ObjetoCor.CorG = 231;
                        obj_circulo_maior.BBoxInternaCirculo.ObjetoCor.CorB = 226;
                    }
                }
            }
        }        

#if CG_Gizmo
        private void Sru3D(){
            GL.LineWidth(3);
            GL.Begin(PrimitiveType.Lines);
            // Linha 1
            GL.Color3(Convert.ToByte(235), Convert.ToByte(62), Convert.ToByte(50));
            GL.Vertex3(0, 0, 0);
            GL.Vertex3(200, 0, 0);
            // Linha 2
            GL.Color3(Convert.ToByte(61), Convert.ToByte(121), Convert.ToByte(0));
            GL.Vertex3(0, 0, 0);
            GL.Vertex3(0, 200, 0);
            GL.End();
        }
#endif
        public double distanciaEuclidiana(double x1, double x2){
            return x2 - x1;
        }
    }    

    class Program{
        static void Main(string[] args){
            Mundo window = Mundo.GetInstance(600, 600);
            window.Title = "CG_N2";
            window.Run(1.0 / 60.0);
        }
    }
}
