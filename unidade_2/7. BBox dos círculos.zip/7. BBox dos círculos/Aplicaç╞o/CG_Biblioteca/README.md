# Diagrama de Classes
Classes utilizadas neste exemplo.

![-- Diagrama de Classe --](http://www.plantuml.com/plantuml/proxy?src=https://raw.githubusercontent.com/dalton-reis/gcg-cg/master/CG_Biblioteca/docs/umlClasses.wsd)

by PlantUML.